# Boston Symbols 1889 — Web bundle

Unzip this download and place the extracted `collection` folder beside your HTML
file. Keep its subfolders together. The examples below then work as written;
adjust their paths if you put the folder elsewhere.

## SVG image

```html
<img src="collection/boston-symbols-1889/svg/multitone/boston-1889-p255-6pt-1.svg"
     alt="Aries zodiac sign, 6-point" height="96">
```

## SVG sprite with custom colours

Serve the HTML and assets from the same website. Set each region's colour and
opacity independently. Use matching secondary and tertiary values for two tones.

```html
<style>
  .revival-cut {
    display: inline-block;
    font-size: 96px;
    height: 1em;
    width: 0.882812em;
    vertical-align: middle;
    --fr-primary-color: #24251f;
    --fr-secondary-color: #a5422c;
    --fr-tertiary-color: #a5422c;
    --fr-primary-opacity: 1;
    --fr-secondary-opacity: 0.55;
    --fr-tertiary-opacity: 0.25;
  }
</style>
<svg class="revival-cut" role="img" aria-label="Aries zodiac sign, 6-point">
  <use href="collection/boston-symbols-1889/web/icons-multitone.svg#boston-1889-p255-6pt-1"></use>
</svg>
```

## Monochrome icon font

```html
<link rel="stylesheet" href="collection/boston-symbols-1889/web/icons.css">
<span class="fr-icon fr-boston-1889-p255-6pt-1" aria-hidden="true"
      style="font-size:96px;color:#a5422c"></span>
<span>Aries zodiac sign, 6-point</span>
```

The font uses the solid artwork. SVG provides the multi-tone version.
Keep `collection/boston-symbols-1889/LICENSE` with the assets when redistributing them.
Copyright (c) 2026 Harold Lehmann. MIT licensed.
